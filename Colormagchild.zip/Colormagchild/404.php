<?php
/**
 * The template for displaying 404 pages (Page Not Found).
 *
 * @package    ThemeGrill
 * @subpackage ColorMag
 * @since      ColorMag 1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
/**
 * Hook: colormag_before_body_content.
 */

do_action( 'colormag_before_body_content' );
?>
	<div id="primary">
		<div id="content" class="clearfix">
			<section class="error-404 not-found">
				<div class="page-content">
<div id="level-404">
<div id="content-404">
	<div id="gears">
				<div id="gears-static"></div>
				<div id="gear-system-1">
					<div id="gear15"></div>
					<div id="gear14"></div>
					<div id="gear13"></div>
				</div>
				<div id="gear-system-2">
					<div id="gear10"></div>
					<div id="gear3"></div>
				</div>
				<div id="gear-system-3">
					<div id="gear9"></div>
					<div id="gear7"></div>
				</div>
				<div id="gear-system-4">
					<div id="gear6"></div>
					<div id="gear4"></div>
				</div>
				<div id="gear-system-5">
					<div id="gear12"></div>
					<div id="gear11"></div>
					<div id="gear8"></div>
				</div>
				<div id="gear1"></div>
				<div id="gear-system-6">
					<div id="gear5"></div>
					<div id="gear2"></div>
				</div>
				<div id="chain-circle"></div>
				<div id="chain"></div>
				<div id="weight"></div>
					</div>
<div id="title-404">
				<h1>Ой! Страница не найдена.</h1>
				<p>Такой страницы нет на нашем сайте. Воспользуйтесь поиском.</p>
	<?php if ( ! dynamic_sidebar( 'colormag_error_404_page_sidebar' ) ) : ?>
						<?php get_search_form(); ?>
					<?php endif; ?>	
<div id="btns-404"><a href="javascript:void(0);" onclick="history.back();" class="btn-404" title="НА ПРЕДЫДУЩУЮ СТРАНИЦУ"><?php _e( "НА ПРЕДЫДУЩУЮ СТРАНИЦУ", 'colormag' )?></a>
	<a href="<?php echo esc_url( home_url('/') ); ?>" class="btn-404" title="НА ГЛАВНУЮ"><?php _e( "НА ГЛАВНУЮ", 'colormag' )?></a></div>
	</div>
	</div>
					</div>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->
	</div><!-- #content -->

							</div><!-- #primary -->
<?php
	
/**colormag_sidebar_select();
/**
 * Hook: colormag_after_body_content.
 */
do_action( 'colormag_after_body_content' );

get_footer();
