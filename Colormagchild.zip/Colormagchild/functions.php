<?php
/*This file is part of Colormagchild, colormag child theme.

All functions of this file will be loaded before of parent theme functions.
Learn more at https://codex.wordpress.org/Child_Themes.

Note: this function loads the parent stylesheet before, then child theme stylesheet
(leave it in place unless you know what you are doing.)
*/

if ( ! function_exists( 'suffice_child_enqueue_child_styles' ) ) {
	function Colormagchild_enqueue_child_styles() {
	    // loading parent style
	    wp_register_style(
	      'parente2-style',
	      get_template_directory_uri() . '/style.css'
	    );

	    wp_enqueue_style( 'parente2-style' );
	    // loading child style
	    wp_register_style(
	      'childe2-style',
	      get_stylesheet_directory_uri() . '/style.css'
	    );
	    wp_enqueue_style( 'childe2-style');
	 }
}
add_action( 'wp_enqueue_scripts', 'Colormagchild_enqueue_child_styles' );

require_once( get_stylesheet_directory() . '/inc/template-tags.php' );

/*Write here your own functions */
add_action( 'woocommerce_after_shop_loop_item_title', 'add_short_description', 9 );
function add_short_description() {
    echo  the_excerpt().'';
}



do_action( 'colormag_action_after' );

if ( ! function_exists( 'colormag_footer_copyright' ) ) :
	/**
	 * Shows the footer copyright information.
	 */
	function colormag_footer_copyright() {

		$site_link = '<a href="' . esc_url( home_url( '/' ) ) . '" title="' . esc_attr( get_bloginfo( 'name', 'display' ) ) . '" ><span>' . get_bloginfo( 'name', 'display' ) . '</span></a>';

		$wp_link = '<a href="https://wordpress.org" target="_blank" title="' . esc_attr__( 'WordPress', 'colormag' ) . '"><span>' . esc_html__( 'WordPress', 'colormag' ) . '</span></a>';

		$tg_link = '<a href="https://themegrill.com/themes/colormag" target="_blank" title="' . esc_attr__( 'ThemeGrill', 'colormag' ) . '" rel="author"><span>' . esc_html__( 'ThemeGrill', 'colormag' ) . '</span></a>';

		$default_footer_value = sprintf( /* Translators: %1$s: Current year, %2$s: Site link */ esc_html__( ' &copy; %1$s %2$s. Все права защищены.', 'colormag' ), date( 'Y' ), $site_link )/* . '<br>' . sprintf( /* Translators: %1$s: Theme name, %2$s: ThemeGrill site link  esc_html__( '', '' ), '', $tg_link ) . ' ' . sprintf( /* Translators: %s: WordPress link  esc_html__( '', '' ), $wp_link )*/;
		$colormag_footer_copyright = '<div class="copyright">' . $default_footer_value . '</div>';

		echo $colormag_footer_copyright; // phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped
	}
endif;

if ( ! function_exists( 'colormag_footer_socket_left_section' ) ) :

	/**
	 * Footer socket area left section.
	 */
	function colormag_footer_socket_left_section() {
		?>
		<div class="footer-socket-left-section">
			<?php do_action( 'colormag_footer_copyright' ); ?>
	<a class="privacy-policy-link" href="https://it37.ru/my-account/privacy-policy/"> &nbsp  Соглашение о конфидециальности</a>	</div>
		<?php
	}
endif;

 add_action('woocommerce_archive_description', 'woocommerce_category_image', 1); function woocommerce_category_image() { global $product; if (is_product_category()) { global $wp_query; $cat = $wp_query->get_queried_object(); $thumbnail_id = get_woocommerce_term_meta($cat->term_id, 'thumbnail_id', true); $image = wp_get_attachment_url($thumbnail_id); if ($image) { echo '<img src="' . esc_url($image) . '" alt="" />'; } } } 

add_filter( 'site_transient_update_plugins', 'filter_plugin_updates' );
function filter_plugin_updates( $value ) {
	unset( $value->response['woo-category-slider-grid/woo-category-slider-grid.php'] );
	return $value;
}

add_filter( 'woocommerce_product_tabs', 'woo_remove_product_tabs', 98 );
function woo_remove_product_tabs( $tabs ) {
//unset( $tabs['description'] ); // убирает описание в карточке товара
//unset( $tabs['reviews'] ); // убирает отзывы в карточке товара
unset( $tabs['additional_information'] ); // убирает детали в карточке товара
return $tabs;
}